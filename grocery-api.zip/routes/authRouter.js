import Express from "express";
import authController from "../controllers/authController.js";

const authRouter = Express.Router()

authRouter.post('/signup', authController.signUp)
authRouter.post('/login' , authController.login)

export default authRouter