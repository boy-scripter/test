import itemsController from "../controllers/itemsController.js";
import Express from "express";
import isAdmin from "../middlewares/isAdmin.js";
import upload from "../middlewares/upload.js";
const router = new Express.Router();

router.get('/', itemsController.items)
router.post('/', isAdmin, upload.single('image'), itemsController.create)
router.post('/update', isAdmin, upload.single('image'), isAdmin, itemsController.update)
router.post('/delete', isAdmin, itemsController.deleteItem)


export default router;