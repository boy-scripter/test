import userController from "../controllers/userController.js";
import Express from "express";


const router = Express.Router()

router.get('/profile', userController.profile)
router.post('/update_profile', userController.update_profile)
router.post('/update_password', userController.update_password)

router.get('/cart', userController.cart)
router.post('/update_cart', userController.update_cart)


export default router