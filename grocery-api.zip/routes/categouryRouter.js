import Express from "express";
import isAdmin from "../middlewares/isAdmin.js";
import categoryController from "../controllers/categoryController.js";
const router = Express.Router()

router.get('/', categoryController.category)
router.post('/', isAdmin, categoryController.create)
router.delete('/', isAdmin, categoryController.remove)

export default router