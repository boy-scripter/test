import userModel from "../models/userModel.js";
import { isValidEmail } from "../utility.js";
import bcrypt from "bcrypt"
import jwt from "jsonwebtoken";

const signUp = async (req, res) => {

    try {
        const { name, email, password } = req.body;

        if (!name || !email || !password) {
            return res.status(422).json({ message: "name, email, and password are required" });
        }

        if (!isValidEmail(email)) return res.status(422).json({ message: "Invalid Email" });

        const user = await userModel.findOne({ email })

        if (user) {
            return res.status(422).json({
                message: "Email already exist"
            })
        }

        userModel({ email, name, password }).save()

        return res.status(200).json({
            message: 'Registration Successfull'
        })
    }
    catch (err) {
        return res.status(500).json({ message: 'Server issue' });
    }

}

const login = async (req, res) => {

    try {
        const { email, password } = req.body

        if (!isValidEmail(email)) return res.status(422).json({ message: 'Invalid Email' });

        const user = await userModel.findOne({ email })

        if (!user) return res.status(422).json({ message: 'user not found' });

        const passwordMatch = await bcrypt.compare(password, user.password)

        if (!passwordMatch) {
            return res.status(422).json({
                message: "Invalid Credentials"
            })
        }

        return res.status(200).json({
            message: 'Login Successfull',
            data: {
                name: user.name,
                email: user.email,
                id: user._id,
                token: jwt.sign({ email, id: user._id , role: user.role}, process.env.JWT_SECRET_KEY)
            }
        })

    }
    catch (err) {
        return res.status(500).json(
            {
                message: 'Server issue',
                error: err.message
            }

        );
    }

}

export default {
    signUp, login
}