import fs from "fs"
import ItemModel from "../models/ItemModel.js";
import categoryModel from "../models/categoryModel.js";


async function items(req, res) {

    try {

        const category = req.params.category?.toString() || false;
        const page = +req.params.page || 0;

        let query = {};

        if (category) {
            query.category = category;
        }

        const items = await ItemModel.find(query).skip(page * 12).limit(12).exec();

        return res.status(200).json({
            message: 'success',
            data: items,
        });

    } catch (err) {
        return res.status(500).json({
            message: "server error",
            error: err.message
        })
    }

}

async function create(req, res) {

    try {
        let data = req.body
        data = await ItemModel.create({ ...data, total_quantity: data.quantity, image: req.filepath });

        await categoryModel.findOneAndUpdate({ _id: data.category }, { $push: { item: data._id } })

        return res.status(201).json({
            message: 'Item created successfully',
            data: data,
        });

    } catch (err) {

        if (req.filepath) fs.unlink(req.filepath);

        return res.status(500).json({
            message: 'Error creating While item',
            error: err.message
        });
    }

}



async function update(req, res) {

    let { name, price, quantity, item } = req.body

    try {

        const data = await ItemModel.findOneAndUpdate({ _id: item }, { name, price, quantity, image: req.filepath, total_quantity: quantity }, { new: true })


        return res.status(200).json({
            message: 'updated Successfully',
            data
        })

    }
    catch (err) {

        return res.status(500).json({
            message: 'Error While Updating Data'
        })
    }


}


async function deleteItem(req, res) {
    let { item } = req.body

    try {
        let data = await ItemModel.findById(item)

        if (!data) throw new Error('item Not Found')

        data.deleteOne()

        await categoryModel.updateOne({ _id: data.category }, { $pull: { item } })

        res.status(200).json({
            message: 'deleted successfully'
        })

    } catch (error) {
        return res.status(500).json({
            message: error.message
        })
    }
}


export default { items, create, update, deleteItem }