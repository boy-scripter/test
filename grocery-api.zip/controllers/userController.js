import { hashSync } from "bcrypt";
import userModel from "../models/userModel.js";
import { isValidEmail } from "../utility.js";

async function profile(req, res) {

    try {

        const data = await userModel.findById(req.user.id).select({ password: false, role: false }).exec()
        return res.status(200).json({
            message: 'success',
            data: data
        })

    } catch (err) {
        return res.status(500).json({
            message: 'error while fetching data'
        })
    }
}


async function update_profile(req, res) {

    try {
        const { name, email } = req.body

        if (!isValidEmail(email)) throw new Error('invalid email')

        const data = await userModel.findOneAndUpdate({ _id: req.user.id }, { name, email })
        return res.status(200).json({
            message: 'updated profile successfully',
            data: { name, email }
        })

    } catch (err) {
        return res.status(500).json({
            message: 'error while updating data'
        })
    }
}


async function update_password(req, res) {

    try {
        const { password } = req.body

        const hashedpassword = hashSync(password, 10)

        await userModel.findOneAndUpdate({ _id: req.user.id }, { password: hashedpassword })
        return res.status(200).json({
            message: 'updated password successfully',
        })

    } catch (err) {
        return res.status(500).json({
            message: 'error while updating password'
        })
    }
}

async function update_cart(req, res) {

    const { item, quantity } = req.body
    try {

        const user = await userModel.findById(req.user.id);

        const existingCartItem = user.cart.find(currentElement => currentElement.item.toString() === item);

        if (existingCartItem) { 

            existingCartItem.quantity = quantity;

        } else {

            user.cart.push({ item, quantity });
        }

        await user.save();

        return res.status(200).json({ message: 'Cart updated successfully', cart: user.cart });
    }
    catch (error) {
        return res.status(500).json({ message: 'Error updating cart', error: error.message });
    }
}

async function cart(req, res) {

    try {
        const data = await userModel.findById(req.user.id).populate('cart.item').select('cart').exec()

        return res.status(200).json({ message: 'Cart items retrieved successfully', cart: data.cart });
    }

    catch (error) {
        return res.status(500).json({ message: 'Error retrieving cart items', error: error.message });
    }
}

export default {
    profile, update_profile, update_password, update_cart, cart
}