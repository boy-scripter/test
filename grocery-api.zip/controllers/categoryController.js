import categoryModel from "../models/categoryModel.js";

async function category(req, res) {
    try {
        const categories = await categoryModel.find({}).populate('item').select({ category: false }).exec()
        return res.status(200).json({
            message: 'success',
            data: categories
        })
    } catch (err) {
        return res.status(500).json({
            message: 'Error While Retreving ',
            error: err.message
        })
    }
}

async function create(req, res) {
    try {
        let data = req.body
        data = await categoryModel(data).save()
        return res.status(200).json({
            message: 'success',
            data: data
        })
    } catch (err) {
        return res.status(500).json({
            message: 'Error While Inserting ',
            error: err.message
        })
    }
}

async function remove(req, res) {
    try {
        const { categoryid } = req.body

        const data = await categoryModel.deleteOne({
            _id: categoryid
        })

        if (!data.deletedCount) throw new Error('Invalid Category Id');

        return res.status(200).json({
            message: 'success',
            data: categoryid
        })


    } catch (err) {
        return res.status(500).json({
            message: 'Error While deleting ',
            error: err.message
        })
    }
}

export default {
    category,
    create,
    remove
}