import jwt from "jsonwebtoken"

function isAdmin(req, res, next) {
    const token = req.header('Authorization');


    if (!token) {
        return res.status(401).json({ message: 'Unauthorized - Token is missing' });
    }

    try {

        req.user = jwt.verify(token, process.env.JWT_SECRET_KEY);

        if (req.user.role != 'admin') return res.status(401).json({ message: 'you are not admin' });

        return next();

    } catch (err) {
        return res.status(401).json({ message: 'Unauthorized - Invalid Token' });
    }
}

export default isAdmin
