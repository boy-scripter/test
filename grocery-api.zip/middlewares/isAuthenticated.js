import jwt from "jsonwebtoken"

function isAuthenticated(req, res, next) {
  const token = req.header('Authorization');


  if (!token) {
    return res.status(401).json({ message: 'Unauthorized - Token is missing' });
  }

  try {

    req.user = jwt.verify(token, process.env.JWT_SECRET_KEY);
    return next();

  } catch (err) {
    res.status(401).json({ message: 'Unauthorized - Invalid Token' });
  }
}

export default isAuthenticated
