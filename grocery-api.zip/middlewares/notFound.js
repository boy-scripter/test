function notFound(req, res) {
   return res.status(404).json({
        message: 'Route Not Found'
    })
}

export default notFound