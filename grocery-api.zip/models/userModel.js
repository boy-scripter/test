import mongoose, { SchemaType } from "mongoose";
import bcrypt from "bcrypt"

const schema = mongoose.Schema({

    name: {
        type: String,
        required: true,
        minlength: 3
    },

    email: {
        type: String,
        required: true,
        unique: true,
        minlength: 5
    },

    password: {
        type: String,
        required: true,
        minlength: 8,
    },

    role: {
        type: String,
        default: 'user',
        required: true,
    }
    ,
    cart: {
        type: [{
            quantity: {
                type: Number,
                required: true,
                min: 1
            },
            item: {
                type: mongoose.Schema.Types.ObjectId,
                required: true,
                ref: "item"
            }
        }],
    },

    purchased: {
        type: [mongoose.Schema.Types.ObjectId],
        ref: 'purchased'
    }

})

schema.pre('save', function () {
    this.password = bcrypt.hashSync(this.password, 10)
})

const userModel = mongoose.model('user', schema);

export default userModel;