import mongoose  from "mongoose";

const schema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    category: {
        type: String,
        required: true
    },
    qunatity: {
        type: Number,
        required: true
    },
    price: {
        type: Number,
        required: true
    }
})

export default mongoose.model('purchased', schema);