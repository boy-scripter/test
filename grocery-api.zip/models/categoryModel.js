import mongoose from "mongoose";

const schema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    item: {
        type: [mongoose.Schema.Types.ObjectId],
        ref: 'item'
    }
})

export default mongoose.model('category', schema)