import Express from "express";
import mongoose from "mongoose";
import dotenv from "dotenv";
import cors from "cors"
import path from "path"

import authRouter from "./routes/authRouter.js";
import itemRouter from "./routes/itemRouter.js";
import categoryRouter from "./routes/categouryRouter.js"
import notFound from "./middlewares/notFound.js";
import userRouter from "./routes/userRoutes.js";

import isAuthenticated from "./middlewares/isAuthenticated.js";

const app = new Express()
app.use(Express.json())
app.use('/api',Express.static(path.join(path.resolve(), 'uploads')))
app.use(cors())
dotenv.config()

mongoose.connect(`mongodb://${process.env.DB_USERNAME}:${process.env.DB_PASSWORD}/${process.env.DB_NAME}?retryWrites=true`)
    .then(
        data => {
            console.log('moongodb is connected')
        }
    ).catch(
        err => {
            console.log('something is wrong while connected mongodb ' + err)
        }
    )


app.get('/api', (req, res) => {
    res.status(200).json({
        message: 'Welcome to Grocery App'
    })
})

app.use('/api', authRouter)
app.use('/api/item', itemRouter)
app.use('/api/category', categoryRouter)
app.use('/api/user', isAuthenticated, userRouter)
app.use(notFound)

app.listen(5000 || process.env.PORT, (err, data) => {
    if (err) return;
    console.log('servcer is listening')
})
