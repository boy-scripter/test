<template>
    <RouterView/>
</template>

<script setup>
</script>