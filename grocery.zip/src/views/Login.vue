<template>
  <div>
    <h2>Login</h2>
    <form @submit.prevent="login">
      <div>
        <label for="email">Email:</label>
        <input type="email" id="email" v-model="email" />
      </div>
      <div>
        <label for="password">Password:</label>
        <input type="password" id="password" v-model="password" />
      </div>
      <button type="submit">Login</button>
    </form>
    <div v-if="error" class="error">{{ error }}</div>
  </div>
</template>

<script>
import { ref } from 'vue';
import axios from 'axios';
import { useRouter } from 'vue-router';

export default {
  setup() {
    const email = ref('');
    const password = ref('');
    const error = ref('');
    const router = useRouter()

    const login = async () => {
      try {
        const response = await axios.post('http://localhost:5000/api/login', {
          email: email.value,
          password: password.value,
        });

        // Check the API response and perform the necessary actions.
        if (response.status === 200) {
          // Successful login
          error.value = '';
          console.log(response.data.data)
          localStorage.setItem('token', response.data.data.token)
          router.push('/admin')
        } else {
          // Failed login
          error.value = 'Invalid email or password';
        }
      } catch (err) {
        // Handle errors from the API request, such as network errors or invalid API response.
        error.value = 'An error occurred during login.';
        console.error(err);
      }
    };

    return {
      email,
      password,
      error,
      login,
    };
  },
};
</script>

<style scoped>
  .error {
    color: red;
    margin-top: 10px;
  }
</style>
