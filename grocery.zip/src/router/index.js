import { createRouter, createWebHistory } from 'vue-router'
import Login from '../views/Login.vue'
import Dashboard from '../views/admin/Dashboard.vue'
import Admin from '../views/admin/Admin.vue'
const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'Login',
      component: Login
    },
    {
      path: '/admin',
      name: 'Admin',
      component: Admin,
      children: [
        {
          path: 'dashboard',
          component: Dashboard
        },
        {
          path: '',
          component: Dashboard
        }
      ]
    }

  ]
})

export default router
